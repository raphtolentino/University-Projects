------------------------------------------------------------------------
This is the project README file. Here, you should describe your project.
Tell the reader (someone who does not know anything about this project)
all he/she needs to know. The comments should usually include at least:
------------------------------------------------------------------------

PROJECT TITLE: Reversi 
PURPOSE OF PROJECT: A simple Reversi Game
SOFTWARE: Made for the BlueJ software
HOW TO START THIS PROJECT: Create a Program object and call
its run method. Call its finish method to end.

Alternatively, run the main method from the Main class.

AUTHORS: David J. Barnes, Raphael Tolentino
USER INSTRUCTIONS:
