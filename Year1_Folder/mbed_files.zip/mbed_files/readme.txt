------------------------------------------------------------------------
This is the project README file. Here, you should describe your project.
Tell the reader (someone who does not know anything about this project)
all he/she needs to know. The comments should usually include at least:
------------------------------------------------------------------------

PROJECT TITLE: Template 
PURPOSE OF PROJECT: A simple template for MBED interaction
using the shed.mbed API
VERSION or DATE: 2017.01.12
HOW TO START THIS PROJECT: Create a Program object and call
its run method. Call its finish method to end.

Alternatively, run the main method from the Main class.

AUTHORS:  Raphael Tolentino
USER INSTRUCTIONS:
------------------------------------------------------------------------
PROJECT TITLE: Transfer
PURPOSE OF PROJECT: A simple file with tests for the MBED
VERSION or DATE: 2017.01.12

AUTHORS: Raphael Tolentino
USER INSTRUCTIONS:
