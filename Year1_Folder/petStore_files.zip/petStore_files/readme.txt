------------------------------------------------------------------------
This is the project README file. Here, you should describe your project.
Tell the reader (someone who does not know anything about this project)
all he/she needs to know. The comments should usually include at least:
------------------------------------------------------------------------

PROJECT TITLE: PetShop 
PURPOSE OF PROJECT: A simple petshop simulator but with missing files
SOTWARE: Made with and for BlueJ software
HOW TO START THIS PROJECT: Create a Program object and call
its run method. Call its finish method to end.

Alternatively, run the main method from the Main class.

AUTHORS: Yang He,  Raphael Tolentino
USER INSTRUCTIONS:
