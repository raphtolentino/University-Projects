------------------------------------------------------------------------
This is the project README file. Here, you should describe your project.
Tell the reader (someone who does not know anything about this project)
all he/she needs to know. The comments should usually include at least:
------------------------------------------------------------------------

PROJECT TITLE: Twitter bot
PURPOSE OF PROJECT: A dairy entry bot that uploads into twitter
HOW TO START THIS PROJECT: Load project.py file, and execute on the IDE

AUTHORS:Raphael Tolentino
