------------------------------------------------------------------------
This is the project README file. Here, you should describe your project.
Tell the reader (someone who does not know anything about this project)
all they need to know. The comments should usually include at least:
------------------------------------------------------------------------

PROJECT TITLE:

Computational Crativity Project

PURPOSE OF PROJECT:

To generate mundane daily activities into Twitter

VERSION or DATE:
1.1 

10/05/2022

HOW TO START THIS PROJECT:

Start Generator:

1. Open project_story.py
2. Click "Run" button
3. The generator will print the desired output into the terminal
4. It will automatically upload into a new tweet on Twitter.

Twitter:

1. open the link "https://twitter.com/KFroggies"
2. Read all previous generated outputs.

AUTHORS:

Raphael Moreira Tolentino

USER INSTRUCTIONS:

Start Generator using Visual Studio :

1. Open project_story.py
2. Click "Run" and "Run without debugging " button
3. The generator will print the desired output into the terminal
4. It will automatically upload into a new tweet on Twitter.

Twitter:

1. open the link "https://twitter.com/KFroggies"
2. Read all previous generated outputs.

