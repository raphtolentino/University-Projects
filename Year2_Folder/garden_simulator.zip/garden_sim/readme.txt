------------------------------------------------------------------------
This is the project README file. Here, you should describe your project.
Tell the reader (someone who does not know anything about this project)
all he/she needs to know. The comments should usually include at least:
------------------------------------------------------------------------

PROJECT TITLE: Garden Simulator
PURPOSE OF PROJECT: A simple garden simulator created with Python 
HOW TO START THIS PROJECT: Load the garden.exe file, and read the result file containing the garden results


AUTHORS:Raphael Tolentino
USER INSTRUCTIONS:
