<?php
session_start();
header('Location: http://raptor.kent.ac.uk/proj/co553m/project/c1-3/websitefiles/features/create_account_login/Login.php');
session_destroy();
?>