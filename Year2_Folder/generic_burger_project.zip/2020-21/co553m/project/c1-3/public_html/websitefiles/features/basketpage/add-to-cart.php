<?php
// start session
session_start();

//get the product info
$id = isset($_GET['id'])